package com.example.weighnix

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class WeighnixApplicationTests {

	@Test
	fun contextLoads() {
	}

}
