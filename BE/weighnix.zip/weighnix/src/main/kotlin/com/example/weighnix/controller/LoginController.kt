package com.example.weighnix.controller

import com.example.weighnix.service.LoginService
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController


@RestController
@RequestMapping("login")
class LoginController(private val loginService: LoginService) {

    @GetMapping("/get")
    fun getAll(): Any {
        return loginService.getAll()
    }

}