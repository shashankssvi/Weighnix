package com.example.weighnix

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class WeighnixApplication

fun main(args: Array<String>) {
	runApplication<WeighnixApplication>(*args)
}
